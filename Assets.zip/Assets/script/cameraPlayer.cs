using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cameraPlayer : MonoBehaviour
{
    // �������� ������
    float xRot;
    float yRot;
    float xRotCurrent;
    float yRotCurrent;
    public Camera player;
    public GameObject playerGameObject;
    public float sensivity = 5f;
    public float smoothTime = 0.05f;
    float currentVelosityX;
    float currentVelosityY;

    // ������ ������
    private float shakeAmount = 0.5f;
    private float speedShake = 1f;
    private Vector3 shakePos;
    private float shakeDistation;
    private Vector3 shakeRotation = Vector3.zero;

    void Start()
    {
        // �������� ������
        Cursor.lockState = CursorLockMode.Locked;

        // ������ ������
        shakePos = transform.position;
    }
    void Update()
    {
        cameraContorl();
        shakeCamera();
    }
    // �������� ������
    void cameraContorl()
    {
        xRot += Input.GetAxis("Mouse X") * sensivity;
        yRot += Input.GetAxis("Mouse Y") * sensivity;
        yRot = Mathf.Clamp(yRot, -60, 60);

        xRotCurrent = Mathf.SmoothDamp(xRotCurrent, xRot, ref currentVelosityX, smoothTime);
        yRotCurrent = Mathf.SmoothDamp(yRotCurrent, yRot, ref currentVelosityY, smoothTime);
        playerGameObject.transform.rotation = Quaternion.Euler(0f, xRotCurrent, 0f);
        player.transform.rotation = Quaternion.Euler(-yRotCurrent, xRotCurrent, 0f);


    }
    // ������ ������
    void shakeCamera()
    {
            shakeDistation += (transform.position - shakePos).magnitude;
            shakePos = transform.position;
            shakeRotation.x = Mathf.Sin(shakeDistation * speedShake) * shakeAmount;
            transform.localEulerAngles += shakeRotation;
    }
}
