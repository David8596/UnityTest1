using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class muny_paysed : MonoBehaviour
{
    public GameObject menu;
    [SerializeField] KeyCode keyMenu;
    bool ismenu = false;

    void Start()
    {
        menu.SetActive(false);
    }

    void Update()
    {
        activeMenu();
    }

    void activeMenu()
    {
        if (Input.GetKeyDown(keyMenu))
        {
            ismenu = !ismenu;
        }
        if (ismenu)
        {
            menu.SetActive(true);
            Cursor.lockState = CursorLockMode.None;
            Time.timeScale = 0f;
        }
        else
        {
            menu.SetActive(false);
            Cursor.lockState = CursorLockMode.Locked;
            Time.timeScale = 1f;
        }
    }
    public void menuCoitry()
    {
        ismenu = false;
    }
    public void menuExit()
    {
        Application.Quit();
        Debug.Log("����� �� ����");
    }
}
